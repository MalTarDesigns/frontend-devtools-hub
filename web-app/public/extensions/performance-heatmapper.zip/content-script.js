// Performance Heatmapper Content Script - Enhanced MVP
(function() {
  'use strict';

  class PerformanceHeatmapper {
    constructor() {
      this.isActive = false;
      this.performanceData = new Map();
      this.overlayElements = new Map();
      this.elementMetrics = new WeakMap();
      this.observers = {};
      this.frameMetrics = [];
      this.lastFrameTime = 0;
      this.config = {
        thresholdGood: 16,     // Green: < 16ms
        thresholdWarning: 50,  // Yellow: 16-50ms
        thresholdBad: 100,     // Red: > 50ms
        samplingRate: 1.0,     // 100% sampling
        showTooltips: true,
        showMetrics: true
      };

      // Wait for DOM to be interactive before initializing
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => this.init());
      } else {
        this.init();
      }
    }

    async init() {
      console.log('🔥 Performance Heatmapper: Initializing...');

      // Load saved settings
      await this.loadSettings();

      // Setup message listeners
      this.setupMessageListeners();

      // Start monitoring if active
      if (this.isActive) {
        this.startMonitoring();
      }
    }

    async loadSettings() {
      try {
        const result = await chrome.storage.local.get(['heatmapEnabled', 'heatmapConfig']);
        this.isActive = result.heatmapEnabled !== false;
        if (result.heatmapConfig) {
          this.config = { ...this.config, ...result.heatmapConfig };
        }
      } catch (e) {
        console.warn('Could not load settings:', e);
        this.isActive = true; // Default to enabled
      }
    }

    setupMessageListeners() {
      chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        switch (request.action) {
          case 'toggle':
            this.toggle();
            sendResponse({ active: this.isActive });
            break;
          case 'getStatus':
            sendResponse({
              active: this.isActive,
              metrics: this.getMetricsSummary()
            });
            break;
          case 'updateConfig':
            this.updateConfig(request.config);
            sendResponse({ success: true });
            break;
          case 'exportData':
            sendResponse({ data: this.exportPerformanceData() });
            break;
          default:
            sendResponse({ error: 'Unknown action' });
        }
        return true; // Keep channel open for async response
      });
    }

    toggle() {
      this.isActive = !this.isActive;
      chrome.storage.local.set({ heatmapEnabled: this.isActive });

      if (this.isActive) {
        this.startMonitoring();
      } else {
        this.stopMonitoring();
      }
    }

    updateConfig(newConfig) {
      this.config = { ...this.config, ...newConfig };
      chrome.storage.local.set({ heatmapConfig: this.config });

      // Re-render overlays with new config
      if (this.isActive) {
        this.updateAllOverlays();
      }
    }

    startMonitoring() {
      console.log('🔥 Performance Heatmapper: Starting monitoring...');

      // Setup all observers
      this.setupPerformanceObserver();
      this.setupMutationObserver();
      this.setupIntersectionObserver();
      this.setupResizeObserver();

      // Start frame monitoring
      this.startFrameMonitoring();

      // Monitor React/Angular components
      this.setupFrameworkDetection();

      // Start periodic updates
      this.startUpdateLoop();

      // Initial scan
      this.scanExistingElements();
    }

    stopMonitoring() {
      console.log('🔥 Performance Heatmapper: Stopping monitoring...');

      // Disconnect all observers
      Object.values(this.observers).forEach(observer => {
        if (observer && observer.disconnect) {
          observer.disconnect();
        }
      });

      // Stop frame monitoring
      if (this.frameAnimationId) {
        cancelAnimationFrame(this.frameAnimationId);
      }

      // Stop update loop
      if (this.updateInterval) {
        clearInterval(this.updateInterval);
      }

      // Clear all overlays
      this.clearAllOverlays();

      // Clear data
      this.performanceData.clear();
      this.elementMetrics = new WeakMap();
    }

    setupPerformanceObserver() {
      try {
        // Monitor various performance entry types
        this.observers.performance = new PerformanceObserver((list) => {
          for (const entry of list.getEntries()) {
            this.processPerformanceEntry(entry);
          }
        });

        // Observe different entry types based on availability
        const supportedTypes = PerformanceObserver.supportedEntryTypes || [];
        const typesToObserve = ['longtask', 'layout-shift', 'largest-contentful-paint', 'first-input']
          .filter(type => supportedTypes.includes(type));

        if (typesToObserve.length > 0) {
          this.observers.performance.observe({ entryTypes: typesToObserve });
        }

        // Also observe paint timing
        if (supportedTypes.includes('paint')) {
          const paintObserver = new PerformanceObserver((list) => {
            for (const entry of list.getEntries()) {
              this.processPaintEntry(entry);
            }
          });
          paintObserver.observe({ entryTypes: ['paint'] });
        }
      } catch (e) {
        console.warn('Performance Observer setup failed:', e);
      }
    }

    processPerformanceEntry(entry) {
      if (entry.entryType === 'longtask') {
        // Long task detected - find affected elements
        const duration = entry.duration;
        const elements = this.findElementsInViewport();

        elements.forEach(element => {
          this.recordMetric(element, {
            type: 'longtask',
            duration: duration,
            timestamp: entry.startTime,
            attribution: entry.attribution?.[0]?.name || 'unknown'
          });
        });
      } else if (entry.entryType === 'layout-shift') {
        // Layout shift - mark affected elements
        entry.sources?.forEach(source => {
          if (source.node) {
            this.recordMetric(source.node, {
              type: 'layout-shift',
              value: entry.value,
              timestamp: entry.startTime
            });
          }
        });
      } else if (entry.entryType === 'largest-contentful-paint') {
        // LCP element
        if (entry.element) {
          this.recordMetric(entry.element, {
            type: 'lcp',
            duration: entry.renderTime || entry.loadTime,
            timestamp: entry.startTime
          });
        }
      }
    }

    processPaintEntry(entry) {
      // Track paint timing globally
      const paintType = entry.name; // 'first-paint' or 'first-contentful-paint'
      const timing = entry.startTime;

      // Apply to visible elements
      const elements = this.findElementsInViewport();
      elements.forEach(element => {
        this.recordMetric(element, {
          type: 'paint',
          paintType: paintType,
          timing: timing,
          timestamp: performance.now()
        });
      });
    }

    setupMutationObserver() {
      this.observers.mutation = new MutationObserver((mutations) => {
        const startTime = performance.now();

        mutations.forEach((mutation) => {
          // Track added nodes
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              this.processNewElement(node, startTime);
            }
          });

          // Track removed nodes
          mutation.removedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              this.cleanupElement(node);
            }
          });

          // Track attribute changes
          if (mutation.type === 'attributes' && mutation.target.nodeType === Node.ELEMENT_NODE) {
            this.recordMetric(mutation.target, {
              type: 'attr-change',
              attribute: mutation.attributeName,
              timestamp: startTime
            });
          }
        });

        // Record mutation batch duration
        const duration = performance.now() - startTime;
        if (duration > 1) {
          this.recordGlobalMetric('mutation-batch', duration);
        }
      });

      // Start observing when DOM is ready
      const startObserving = () => {
        if (document.body) {
          this.observers.mutation.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeOldValue: false,
            characterData: false
          });
        }
      };

      if (document.body) {
        startObserving();
      } else {
        document.addEventListener('DOMContentLoaded', startObserving);
      }
    }

    setupIntersectionObserver() {
      // Track when elements enter/leave viewport
      this.observers.intersection = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            this.trackElement(entry.target);
          } else {
            this.untrackElement(entry.target);
          }
        });
      }, {
        threshold: [0, 0.25, 0.5, 0.75, 1.0]
      });
    }

    setupResizeObserver() {
      // Track resize operations which can be expensive
      this.observers.resize = new ResizeObserver((entries) => {
        entries.forEach(entry => {
          const element = entry.target;

          // Check if size actually changed
          const previousSize = this.elementMetrics.get(element)?.size;
          const currentSize = {
            width: entry.contentRect.width,
            height: entry.contentRect.height
          };

          if (previousSize &&
              (Math.abs(previousSize.width - currentSize.width) > 1 ||
               Math.abs(previousSize.height - currentSize.height) > 1)) {
            this.recordMetric(element, {
              type: 'resize',
              from: previousSize,
              to: currentSize,
              timestamp: performance.now()
            });
          }
        });
      });
    }

    setupFrameworkDetection() {
      // Detect React components
      this.detectReactComponents();

      // Detect Angular components
      this.detectAngularComponents();

      // Detect Vue components
      this.detectVueComponents();
    }

    detectReactComponents() {
      // React 16+ uses __reactInternalFiber or _reactInternalFiber
      // React 17+ uses __reactFiber or _reactFiber
      const reactProps = ['__reactInternalFiber', '_reactInternalFiber', '__reactFiber', '_reactFiber', '__reactInternalInstance'];

      const isReactComponent = (element) => {
        return reactProps.some(prop => {
          const hasProp = element[prop] !== undefined;
          if (hasProp) {
            // Try to get component name
            const fiber = element[prop];
            const componentName = fiber?.elementType?.name || fiber?.type?.name || 'Unknown';
            this.recordMetric(element, {
              type: 'framework',
              framework: 'React',
              component: componentName,
              timestamp: performance.now()
            });
          }
          return hasProp;
        });
      };

      // Check existing elements
      document.querySelectorAll('*').forEach(element => {
        isReactComponent(element);
      });

      // Hook into React DevTools if available
      if (window.__REACT_DEVTOOLS_GLOBAL_HOOK__) {
        const hook = window.__REACT_DEVTOOLS_GLOBAL_HOOK__;
        const originalOnCommitFiberRoot = hook.onCommitFiberRoot;

        hook.onCommitFiberRoot = (id, root, priorityLevel) => {
          // Measure React render time
          const renderStart = performance.now();

          if (originalOnCommitFiberRoot) {
            originalOnCommitFiberRoot.call(hook, id, root, priorityLevel);
          }

          const renderDuration = performance.now() - renderStart;
          if (renderDuration > 1) {
            this.recordGlobalMetric('react-render', renderDuration);
          }
        };
      }
    }

    detectAngularComponents() {
      // Angular uses ng-version attribute and _ngcontent- attributes
      const angularElements = document.querySelectorAll('[ng-version], [_ngcontent], [_nghost]');

      angularElements.forEach(element => {
        // Try to get component name from debug info
        const debugElement = window.ng?.getComponent?.(element);
        const componentName = debugElement?.constructor?.name || 'Unknown';

        this.recordMetric(element, {
          type: 'framework',
          framework: 'Angular',
          component: componentName,
          timestamp: performance.now()
        });
      });

      // Hook into Angular change detection if available
      if (window.ng?.profiler) {
        const profiler = window.ng.profiler;
        const originalTimeChangeDetection = profiler.timeChangeDetection;

        profiler.timeChangeDetection = (...args) => {
          const result = originalTimeChangeDetection.apply(profiler, args);
          if (result?.msPerTick) {
            this.recordGlobalMetric('angular-cd', result.msPerTick);
          }
          return result;
        };
      }
    }

    detectVueComponents() {
      // Vue 2 uses __vue__ property, Vue 3 uses __vueParentComponent
      const vueElements = document.querySelectorAll('*');

      vueElements.forEach(element => {
        const vueInstance = element.__vue__ || element.__vueParentComponent;
        if (vueInstance) {
          const componentName = vueInstance.$options?.name || vueInstance.type?.name || 'Unknown';

          this.recordMetric(element, {
            type: 'framework',
            framework: 'Vue',
            component: componentName,
            timestamp: performance.now()
          });
        }
      });
    }

    startFrameMonitoring() {
      let lastTime = performance.now();
      let frameCount = 0;

      const monitorFrame = (currentTime) => {
        const frameDuration = currentTime - lastTime;
        frameCount++;

        // Track frame metrics
        this.frameMetrics.push({
          duration: frameDuration,
          timestamp: currentTime
        });

        // Keep only last 60 frames (1 second at 60fps)
        if (this.frameMetrics.length > 60) {
          this.frameMetrics.shift();
        }

        // Detect janky frames (> 16.67ms for 60fps)
        if (frameDuration > 16.67) {
          // Find active/visible elements to attribute the jank
          const visibleElements = this.findElementsInViewport();
          const sample = visibleElements.slice(0, 10); // Sample top 10 elements

          sample.forEach(element => {
            this.recordMetric(element, {
              type: 'jank',
              frameDuration: frameDuration,
              timestamp: currentTime
            });
          });
        }

        lastTime = currentTime;

        if (this.isActive) {
          this.frameAnimationId = requestAnimationFrame(monitorFrame);
        }
      };

      this.frameAnimationId = requestAnimationFrame(monitorFrame);
    }

    findElementsInViewport() {
      const elements = [];
      const viewportHeight = window.innerHeight;
      const viewportWidth = window.innerWidth;

      // Get all elements (sampling for performance)
      const allElements = document.querySelectorAll('*');
      const step = Math.max(1, Math.floor(allElements.length / 100)); // Sample up to 100 elements

      for (let i = 0; i < allElements.length; i += step) {
        const element = allElements[i];
        const rect = element.getBoundingClientRect();

        // Check if element is in viewport
        if (rect.bottom >= 0 && rect.top <= viewportHeight &&
            rect.right >= 0 && rect.left <= viewportWidth &&
            rect.width > 0 && rect.height > 0) {
          elements.push(element);
        }
      }

      return elements;
    }

    processNewElement(element, startTime) {
      const loadTime = performance.now() - startTime;

      // Record element creation time
      this.recordMetric(element, {
        type: 'creation',
        duration: loadTime,
        timestamp: startTime
      });

      // Start tracking this element
      this.trackElement(element);

      // Process child elements
      element.querySelectorAll('*').forEach(child => {
        this.trackElement(child);
      });
    }

    trackElement(element) {
      // Skip our own overlays
      if (element.classList?.contains('perf-heatmap-overlay')) {
        return;
      }

      // Skip tiny or invisible elements
      const rect = element.getBoundingClientRect();
      if (rect.width < 10 || rect.height < 10) {
        return;
      }

      // Add to intersection observer
      if (this.observers.intersection) {
        this.observers.intersection.observe(element);
      }

      // Add to resize observer for significant elements
      if (this.observers.resize && (rect.width > 100 || rect.height > 100)) {
        this.observers.resize.observe(element);
      }

      // Detect React/Angular/Vue components
      this.detectFrameworkComponent(element);

      // Analyze element complexity
      this.analyzeElementComplexity(element);
    }

    untrackElement(element) {
      // Remove from observers
      if (this.observers.intersection) {
        this.observers.intersection.unobserve(element);
      }
      if (this.observers.resize) {
        this.observers.resize.unobserve(element);
      }

      // Remove overlay if exists
      this.removeOverlay(element);
    }

    cleanupElement(element) {
      this.untrackElement(element);

      // Cleanup children
      element.querySelectorAll('*').forEach(child => {
        this.untrackElement(child);
      });
    }

    detectFrameworkComponent(element) {
      // Check for React
      const reactProps = ['__reactInternalFiber', '_reactInternalFiber', '__reactFiber', '_reactFiber'];
      const hasReact = reactProps.some(prop => element[prop]);

      // Check for Angular
      const hasAngular = element.hasAttribute('_ngcontent') ||
                        element.hasAttribute('_nghost') ||
                        element.hasAttribute('ng-version');

      // Check for Vue
      const hasVue = !!element.__vue__ || !!element.__vueParentComponent;

      if (hasReact || hasAngular || hasVue) {
        const framework = hasReact ? 'React' : hasAngular ? 'Angular' : 'Vue';
        this.recordMetric(element, {
          type: 'framework-component',
          framework: framework,
          timestamp: performance.now()
        });
      }
    }

    analyzeElementComplexity(element) {
      let complexityScore = 0;
      const startTime = performance.now();

      // DOM complexity
      const childCount = element.children.length;
      const descendantCount = element.querySelectorAll('*').length;

      if (childCount > 10) complexityScore += 1;
      if (childCount > 50) complexityScore += 2;
      if (descendantCount > 100) complexityScore += 3;

      // Style complexity
      const styles = window.getComputedStyle(element);

      // Check for expensive CSS properties
      const expensiveProps = {
        'filter': 3,
        'backdrop-filter': 4,
        'box-shadow': 1,
        'transform': 1,
        'opacity': 0.5,
        'mix-blend-mode': 2,
        'will-change': 1
      };

      for (const [prop, weight] of Object.entries(expensiveProps)) {
        const value = styles.getPropertyValue(prop);
        if (value && value !== 'none' && value !== 'normal' && value !== 'auto' && value !== '1') {
          complexityScore += weight;
        }
      }

      // Animation detection
      if (styles.animation !== 'none' || styles.transition !== 'none') {
        complexityScore += 2;
      }

      // Size penalty for very large elements
      const rect = element.getBoundingClientRect();
      const area = rect.width * rect.height;
      const viewportArea = window.innerWidth * window.innerHeight;

      if (area > viewportArea * 0.5) complexityScore += 2;
      if (area > viewportArea * 0.8) complexityScore += 3;

      const analysisTime = performance.now() - startTime;

      if (complexityScore > 0 || analysisTime > 1) {
        this.recordMetric(element, {
          type: 'complexity',
          score: complexityScore,
          analysisTime: analysisTime,
          timestamp: startTime
        });
      }
    }

    recordMetric(element, metric) {
      if (!element || !metric) return;

      // Get or create metrics for this element
      let metrics = this.elementMetrics.get(element);
      if (!metrics) {
        metrics = {
          element: element,
          identifier: this.getElementIdentifier(element),
          metrics: [],
          summary: {
            totalDuration: 0,
            jankCount: 0,
            complexityScore: 0,
            framework: null
          }
        };
        this.elementMetrics.set(element, metrics);
      }

      // Add metric to history
      metrics.metrics.push(metric);

      // Keep only recent metrics (last 10 seconds)
      const cutoff = performance.now() - 10000;
      metrics.metrics = metrics.metrics.filter(m => m.timestamp > cutoff);

      // Update summary
      this.updateMetricsSummary(metrics);
    }

    updateMetricsSummary(metrics) {
      const summary = metrics.summary;

      // Reset summary
      summary.totalDuration = 0;
      summary.jankCount = 0;
      summary.complexityScore = 0;

      // Calculate summary from metrics
      metrics.metrics.forEach(metric => {
        switch (metric.type) {
          case 'longtask':
          case 'creation':
            summary.totalDuration += metric.duration || 0;
            break;
          case 'jank':
            summary.jankCount++;
            summary.totalDuration += (metric.frameDuration - 16.67); // Add excess time
            break;
          case 'complexity':
            summary.complexityScore = Math.max(summary.complexityScore, metric.score);
            break;
          case 'framework':
          case 'framework-component':
            summary.framework = metric.framework;
            break;
        }
      });

      // Calculate average duration
      if (metrics.metrics.length > 0) {
        summary.averageDuration = summary.totalDuration / metrics.metrics.length;
      }
    }

    recordGlobalMetric(type, value) {
      // Record metrics that apply globally
      console.log(`Global metric: ${type} = ${value}ms`);

      // Apply to all tracked elements with decay
      this.elementMetrics.forEach((metrics) => {
        this.recordMetric(metrics.element, {
          type: 'global-' + type,
          value: value,
          timestamp: performance.now()
        });
      });
    }

    getElementIdentifier(element) {
      // Create a unique identifier for the element
      if (element.id) return '#' + element.id;

      const classList = Array.from(element.classList).join('.');
      if (classList) return element.tagName + '.' + classList;

      // Use path in DOM
      let path = element.tagName;
      let parent = element.parentElement;
      let depth = 0;

      while (parent && parent !== document.body && depth < 3) {
        const index = Array.from(parent.children).indexOf(element);
        path = `${parent.tagName}[${index}]/${path}`;
        parent = parent.parentElement;
        depth++;
      }

      return path;
    }

    scanExistingElements() {
      console.log('Scanning existing elements...');

      // Sample elements for initial scan
      const elements = document.querySelectorAll('*');
      const step = Math.max(1, Math.floor(elements.length / 200)); // Sample up to 200 elements

      for (let i = 0; i < elements.length; i += step) {
        this.trackElement(elements[i]);
      }
    }

    startUpdateLoop() {
      // Update overlays periodically
      this.updateInterval = setInterval(() => {
        if (this.isActive) {
          this.updateAllOverlays();
        }
      }, 100); // Update every 100ms for smooth visualization
    }

    updateAllOverlays() {
      const processedElements = new Set();

      // Update overlays for tracked elements
      this.elementMetrics.forEach((metrics, element) => {
        // Skip if element is no longer in DOM
        if (!document.body.contains(element)) {
          this.elementMetrics.delete(element);
          this.removeOverlay(element);
          return;
        }

        // Calculate performance score
        const score = this.calculatePerformanceScore(metrics);

        if (score > 0) {
          this.updateOverlay(element, score, metrics);
          processedElements.add(element);
        }
      });

      // Remove overlays for elements no longer being tracked
      this.overlayElements.forEach((overlay, element) => {
        if (!processedElements.has(element)) {
          this.removeOverlay(element);
        }
      });
    }

    calculatePerformanceScore(metrics) {
      const summary = metrics.summary;
      let score = 0;

      // Base score on average duration
      if (summary.averageDuration) {
        score = summary.averageDuration;
      }

      // Add complexity penalty
      score += summary.complexityScore * 5;

      // Add jank penalty
      score += summary.jankCount * 10;

      // Boost score for framework components (they're usually interesting)
      if (summary.framework) {
        score = Math.max(score, 10);
      }

      return score;
    }

    updateOverlay(element, score, metrics) {
      // Get or create overlay
      let overlay = this.overlayElements.get(element);

      if (!overlay) {
        overlay = this.createOverlay();
        this.overlayElements.set(element, overlay);
      }

      // Update overlay position and style
      const rect = element.getBoundingClientRect();

      // Skip if element is not visible
      if (rect.width === 0 || rect.height === 0) {
        overlay.style.display = 'none';
        return;
      }

      overlay.style.display = 'block';
      overlay.style.left = (rect.left + window.scrollX) + 'px';
      overlay.style.top = (rect.top + window.scrollY) + 'px';
      overlay.style.width = rect.width + 'px';
      overlay.style.height = rect.height + 'px';

      // Apply color based on score
      const color = this.getColorForScore(score);
      overlay.style.borderColor = color.border;
      overlay.style.backgroundColor = color.background;

      // Update metrics display
      if (this.config.showMetrics) {
        const metricsDisplay = overlay.querySelector('.perf-metrics');
        if (metricsDisplay) {
          metricsDisplay.textContent = `${Math.round(score)}ms`;
          metricsDisplay.style.display = score > 5 ? 'block' : 'none';
        }
      }

      // Update tooltip
      if (this.config.showTooltips) {
        const tooltip = overlay.querySelector('.perf-tooltip');
        if (tooltip) {
          const details = this.getMetricsDetails(metrics);
          tooltip.innerHTML = details;
        }
      }
    }

    createOverlay() {
      const overlay = document.createElement('div');
      overlay.className = 'perf-heatmap-overlay';
      overlay.style.cssText = `
        position: absolute;
        pointer-events: none;
        z-index: 999998;
        border: 2px solid;
        border-radius: 4px;
        transition: all 0.3s ease;
        box-sizing: border-box;
      `;

      // Add metrics display
      const metricsDisplay = document.createElement('div');
      metricsDisplay.className = 'perf-metrics';
      metricsDisplay.style.cssText = `
        position: absolute;
        top: 2px;
        right: 2px;
        background: rgba(0, 0, 0, 0.8);
        color: white;
        padding: 2px 6px;
        border-radius: 3px;
        font-family: 'Courier New', monospace;
        font-size: 11px;
        font-weight: bold;
        pointer-events: none;
        z-index: 1;
      `;
      overlay.appendChild(metricsDisplay);

      // Add tooltip (hidden by default)
      const tooltip = document.createElement('div');
      tooltip.className = 'perf-tooltip';
      tooltip.style.cssText = `
        position: absolute;
        bottom: 100%;
        left: 50%;
        transform: translateX(-50%);
        background: rgba(0, 0, 0, 0.9);
        color: white;
        padding: 8px;
        border-radius: 4px;
        font-family: 'Courier New', monospace;
        font-size: 11px;
        white-space: nowrap;
        pointer-events: none;
        display: none;
        margin-bottom: 5px;
        max-width: 300px;
      `;
      overlay.appendChild(tooltip);

      // Show tooltip on hover (using a transparent hover area)
      const hoverArea = document.createElement('div');
      hoverArea.style.cssText = `
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        pointer-events: auto;
        background: transparent;
      `;

      hoverArea.addEventListener('mouseenter', () => {
        tooltip.style.display = 'block';
      });

      hoverArea.addEventListener('mouseleave', () => {
        tooltip.style.display = 'none';
      });

      overlay.appendChild(hoverArea);

      document.body.appendChild(overlay);
      return overlay;
    }

    getColorForScore(score) {
      // Color coding based on performance score (in ms)
      if (score < this.config.thresholdGood) {
        // Green - Good performance
        return {
          border: 'rgba(34, 197, 94, 0.8)',
          background: 'rgba(34, 197, 94, 0.15)'
        };
      } else if (score < this.config.thresholdWarning) {
        // Yellow - Warning
        return {
          border: 'rgba(250, 204, 21, 0.8)',
          background: 'rgba(250, 204, 21, 0.15)'
        };
      } else if (score < this.config.thresholdBad) {
        // Orange - Bad
        return {
          border: 'rgba(251, 146, 60, 0.8)',
          background: 'rgba(251, 146, 60, 0.15)'
        };
      } else {
        // Red - Critical
        return {
          border: 'rgba(239, 68, 68, 0.8)',
          background: 'rgba(239, 68, 68, 0.15)'
        };
      }
    }

    getMetricsDetails(metrics) {
      const summary = metrics.summary;
      const details = [];

      details.push(`<strong>${metrics.identifier}</strong>`);

      if (summary.framework) {
        details.push(`Framework: ${summary.framework}`);
      }

      if (summary.averageDuration) {
        details.push(`Avg Time: ${summary.averageDuration.toFixed(1)}ms`);
      }

      if (summary.jankCount > 0) {
        details.push(`Jank Frames: ${summary.jankCount}`);
      }

      if (summary.complexityScore > 0) {
        details.push(`Complexity: ${summary.complexityScore.toFixed(1)}`);
      }

      // Recent metrics
      const recentMetrics = metrics.metrics.slice(-3);
      if (recentMetrics.length > 0) {
        details.push('<br>Recent Events:');
        recentMetrics.forEach(m => {
          const time = ((performance.now() - m.timestamp) / 1000).toFixed(1);
          details.push(`• ${m.type} (${time}s ago)`);
        });
      }

      return details.join('<br>');
    }

    removeOverlay(element) {
      const overlay = this.overlayElements.get(element);
      if (overlay && overlay.parentNode) {
        overlay.parentNode.removeChild(overlay);
      }
      this.overlayElements.delete(element);
    }

    clearAllOverlays() {
      this.overlayElements.forEach((overlay) => {
        if (overlay.parentNode) {
          overlay.parentNode.removeChild(overlay);
        }
      });
      this.overlayElements.clear();
    }

    getMetricsSummary() {
      const summary = {
        elementsTracked: this.elementMetrics.size,
        overlaysActive: this.overlayElements.size,
        performanceIssues: 0,
        frameworkComponents: {
          React: 0,
          Angular: 0,
          Vue: 0
        },
        averageFrameTime: 0
      };

      // Count performance issues and framework components
      this.elementMetrics.forEach((metrics) => {
        const score = this.calculatePerformanceScore(metrics);
        if (score > this.config.thresholdWarning) {
          summary.performanceIssues++;
        }

        if (metrics.summary.framework) {
          summary.frameworkComponents[metrics.summary.framework]++;
        }
      });

      // Calculate average frame time
      if (this.frameMetrics.length > 0) {
        const totalFrameTime = this.frameMetrics.reduce((sum, f) => sum + f.duration, 0);
        summary.averageFrameTime = totalFrameTime / this.frameMetrics.length;
      }

      return summary;
    }

    exportPerformanceData() {
      const data = {
        timestamp: new Date().toISOString(),
        url: window.location.href,
        metrics: [],
        summary: this.getMetricsSummary()
      };

      this.elementMetrics.forEach((metrics, element) => {
        data.metrics.push({
          identifier: metrics.identifier,
          score: this.calculatePerformanceScore(metrics),
          summary: metrics.summary,
          recentEvents: metrics.metrics.slice(-10)
        });
      });

      return data;
    }
  }

  // Initialize the performance heatmapper
  window.__performanceHeatmapper = new PerformanceHeatmapper();
})();